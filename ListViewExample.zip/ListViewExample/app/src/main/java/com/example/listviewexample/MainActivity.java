package com.example.listviewexample;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
//Declaration
    ListView list;
    ArrayAdapter<String> arrayAdapter;
    ArrayList<String> arrayList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
// Referencing
        list = findViewById(R.id.listview);

// Dataset
        arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Mango");
        arrayList.add("Guava");
        arrayList.add("Banana");
        arrayList.add("Pineapple");
        arrayList.add("Kiwi");
        arrayList.add("Apple");
        arrayList.add("Mango");
        arrayList.add("Guava");
        arrayList.add("Banana");
        arrayList.add("Pineapple");
        arrayList.add("Kiwi");
        arrayList.add("Apple");
        arrayList.add("Mango");
        arrayList.add("Guava");
        arrayList.add("Banana");
        arrayList.add("Pineapple");
        arrayList.add("Kiwi");
//Adapter with 3 parameters

//        arrayAdapter = new ArrayAdapter<>(
//                MainActivity.this,
//                android.R.layout.simple_list_item_1,
//                arrayList
//                );

//Adapter with 4 parameters

        arrayAdapter = new ArrayAdapter<>(
                MainActivity.this,
                R.layout.custom,
                R.id.c_t_data,
                arrayList
        );


//Setting Data to adapter
        list.setAdapter(arrayAdapter);
//Listener on Clicked item on list
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String item = parent.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this,item,Toast.LENGTH_SHORT).show();
            }
        });

    }
}