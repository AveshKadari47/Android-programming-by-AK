package com.example.a3textboxes;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etPrincipal, etRate, etTime;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPrincipal = findViewById(R.id.etPrincipal);
        etRate = findViewById(R.id.etRate);
        etTime = findViewById(R.id.etTime);
        tvResult = findViewById(R.id.tvResult);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        double P = Double.parseDouble(etPrincipal.getText().toString());
        double R = Double.parseDouble(etRate.getText().toString());
        double T = Double.parseDouble(etTime.getText().toString());

        int id = item.getItemId();

        if (id == R.id.simple) {

            double SI = (P * R * T) / 100;
            tvResult.setText("Simple Interest: " + SI);
            return true;

        } else if (id == R.id.compound) {

            double CI = P * Math.pow((1 + R / 100), T) - P;
            tvResult.setText("Compound Interest: " + CI);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}