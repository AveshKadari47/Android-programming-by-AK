package com.example.calulator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText etResult;
    double firstNumber = 0;
    String operator = "";
    boolean isNewInput = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etResult = findViewById(R.id.etResult);
        GridLayout gridLayout = findViewById(R.id.gridLayout);

        for (int i = 0; i < gridLayout.getChildCount(); i++) {
            View view = gridLayout.getChildAt(i);

            if (view instanceof Button) {
                Button button = (Button) view;
                button.setOnClickListener(v ->
                        handleInput(button.getText().toString())
                );
            }
        }
    }

    private void handleInput(String value) {

        if (value.matches("[0-9]")) {
            if (isNewInput) {
                etResult.setText(value);
                isNewInput = false;
            } else {
                etResult.append(value);
            }
        }

        else if (value.matches("[+\\-*/]")) {
            firstNumber = Double.parseDouble(etResult.getText().toString());
            operator = value;
            isNewInput = true;
        }

        else if (value.equals("=")) {
            double secondNumber = Double.parseDouble(etResult.getText().toString());
            double result = calculate(firstNumber, secondNumber, operator);
            etResult.setText(String.valueOf(result));
            isNewInput = true;
        }

        else if (value.equals("C")) {
            etResult.setText("0");
            firstNumber = 0;
            operator = "";
            isNewInput = true;
        }
    }

    private double calculate(double a, double b, String op) {
        switch (op) {
            case "+": return a + b;
            case "-": return a - b;
            case "*": return a * b;
            case "/": return b != 0 ? a / b : 0;
            default: return 0;
        }
    }
}
